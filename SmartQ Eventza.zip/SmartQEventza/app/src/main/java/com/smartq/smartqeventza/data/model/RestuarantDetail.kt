package com.smartq.smartqeventza.data.model


import com.google.gson.annotations.SerializedName
import android.support.annotation.Keep
import com.google.gson.annotations.Expose

@Keep
data class RestuarantDetail(
    @SerializedName("minimumdeliveryamount")
    @Expose
    val minimumdeliveryamount: Boolean,
    @SerializedName("minimumdeliveryamount_number")
    @Expose
    val minimumdeliveryamountNumber: Int,
    @SerializedName("name")
    @Expose
    val name: String,
    @SerializedName("phonenumber")
    @Expose
    val phonenumber: String,
    @SerializedName("servingtime")
    @Expose
    val servingtime: String,
    @SerializedName("thumbnail")
    @Expose
    val thumbnail: String,
    @SerializedName("uniqid")
    @Expose
    val uniqid: String,
    @SerializedName("vegflag")
    @Expose
    val vegflag: String
)