package com.smartq.smartqeventza.data.model


import com.google.gson.annotations.SerializedName
import android.support.annotation.Keep
import com.google.gson.annotations.Expose

@Keep
data class MenuX(
    @SerializedName("ABCMAIN:angrezitadka")
    @Expose
    val aBCMAINAngrezitadka: List<ABCMAINAngrezitadka>,
    @SerializedName("ABCMAIN:bespoke")
    @Expose
    val aBCMAINBespoke: List<ABCMAINBespoke>
)