package com.smartq.smartqeventza.data.model


import com.google.gson.annotations.SerializedName
import android.support.annotation.Keep
import com.google.gson.annotations.Expose

@Keep
data class ABCMAINBespoke(
    @SerializedName("category")
    @Expose
    val category: String,
    @SerializedName("fooddescription")
    @Expose
    val fooddescription: String,
    @SerializedName("foodid")
    @Expose
    val foodid: String,
    @SerializedName("foodname")
    @Expose
    val foodname: String,
    @SerializedName("imageurl")
    @Expose
    val imageurl: String,
    @SerializedName("price")
    @Expose
    val price: Double,
    @SerializedName("servingtime")
    @Expose
    val servingtime: String,
    @SerializedName("sessionlist")
    @Expose
    val sessionlist: List<String>
)