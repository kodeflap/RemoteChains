package com.smartq.smartqeventza.data.model


import com.google.gson.annotations.SerializedName
import android.support.annotation.Keep
import com.google.gson.annotations.Expose

@Keep
data class User(
    @SerializedName("ecash")
    @Expose
    val ecash: Int,
    @SerializedName("emailverified")
    @Expose
    val emailverified: Boolean,
    @SerializedName("imageurl")
    @Expose
    val imageurl: String,
    @SerializedName("mobilenumber")
    @Expose
    val mobilenumber: String,
    @SerializedName("name")
    @Expose
    val name: String,
    @SerializedName("selectedfoodcourt")
    @Expose
    val selectedfoodcourt: String,
    @SerializedName("selectedfoodcourtname")
    @Expose
    val selectedfoodcourtname: String,
    @SerializedName("verified")
    @Expose
    val verified: Boolean
)