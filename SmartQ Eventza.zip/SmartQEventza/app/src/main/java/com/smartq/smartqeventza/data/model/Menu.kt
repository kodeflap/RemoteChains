package com.smartq.smartqeventza.data.model


import com.google.gson.annotations.SerializedName
import android.support.annotation.Keep
import com.google.gson.annotations.Expose

@Keep
data class Menu(
    @SerializedName("menu")
    @Expose
    val menu: MenuX,
    @SerializedName("restuarant_details")
    @Expose
    val restuarantDetails: List<RestuarantDetail>,
    @SerializedName("user")
    @Expose
    val user: User
)